from matplotlib import pyplot as plt
import pandas as pd

fig = plt.figure(figsize=(10,8))

mk2 = pd.read_csv('mk2_plt.csv')
x1 = mk2['os']
y1 = mk2['mean']
err1 = mk2['std_err']


pairs = pd.read_csv('pairs_plt.csv')
x2 = pairs['os']
y2 = pairs['mean']
err2 = pairs['std_err']

plt.errorbar(x1, y1, err1, fmt='k*-', capsize=5)
plt.errorbar(x2, y2, err2, fmt='rx-', capsize=5)

plt.legend(('mk2', 'pairs'))
plt.title('Mk2 vs Pairs')
plt.ylabel('Avg tiles to win')
plt.xlabel('Starting score')
plt.grid(visible=True)
plt.savefig('pairs_mk2.svg')
plt.show()
