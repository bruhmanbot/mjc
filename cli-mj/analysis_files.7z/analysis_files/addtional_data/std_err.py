import pandas as pd
import numpy as np

raw = pd.read_csv('./mk2_var.csv')
keys = set(raw['openingScore'])
alpha_output = {}

for i in keys:
    filtered = raw[raw['openingScore'] == i]
    tilesUsed = np.array(filtered['tiles'])
    sample_sd = np.std(tilesUsed, ddof=1)

    alpha = sample_sd / np.sqrt(len(tilesUsed))

    alpha_output[i] = alpha

output_df = pd.DataFrame.from_dict(alpha_output, orient='index')

print (output_df.head())

output_df.to_csv('./mk2_stderr.csv')

